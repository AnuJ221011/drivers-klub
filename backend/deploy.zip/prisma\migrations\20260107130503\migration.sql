-- AlterTable
ALTER TABLE "PreferenceDefination" ALTER COLUMN "defaultValue" SET DEFAULT false;
